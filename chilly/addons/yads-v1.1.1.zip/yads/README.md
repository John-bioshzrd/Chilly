## YADS - Yet Another Dialogue System

Documentation: https://github.com/jkulawik/yads/wiki

## Changelog

v1.1.0:
- added Jinja-style multiline comment support

v1.1.1:
- fix highlighter error: https://github.com/jkulawik/yads/issues/13
